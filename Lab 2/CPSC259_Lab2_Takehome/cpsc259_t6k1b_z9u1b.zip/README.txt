 "We have read and understood the plagiarism policies at 
https://www.cs.ubc.ca/our-department/administration/policies/collaboration 
and we understand that no excuse for plagiarism will be accepted, including 
any listed in http://www.cs.ubc.ca/~tmm/courses/cheat.html".

/*
 File:        dna.c
 Purpose:     Consumes a formatted DNA sequence file
			  to determine which of a group of candidate
			  sequences of nucleotides best matches a
			  specified sample.  The formatted DNA
			  sequence file is a txt file (threes samples
			  are provided in the Resource Files folder).
 Author:	Karmen Wang and Matthew Lee
 Student #s:	54144183 and 78927936
 CS Accounts:	t6k1b and z9u1b
 Date:			oct 7 2018
 */

/*
 File:        dna.h
 Purpose:     Contains constants, prototypes, and two
			  helpful arrays.
 Author:	 Karmen Wang and Matthew Lee
 Student #s:	54144183 and 78927936
 CS Accounts:	t6k1b and z9u1b
 Date:			oct 7 2018
 */

checking for correctness: used debugger to check for mismatched variable types 
	as well as the terminal to check if values printed matched the result.txt files


challenges: keeping track of how pointer logic and dynamic memory worked and general in caluclate_score 

Hours spent: 3-4 hours in total.. mostly debugging 

How the assignment was split: 45% for matthew  and 55% for karmen. Karmen added comments and made sure everything
	was good for hand in. Programming was split evenly between the two partners.

Additional Comments: Matthew and Karmen work well together and split up workload evenly. :)