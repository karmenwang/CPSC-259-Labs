 "We have read and understood the plagiarism policies at 
https://www.cs.ubc.ca/our-department/administration/policies/collaboration 
and we understand that no excuse for plagiarism will be accepted, including 
any listed in http://www.cs.ubc.ca/~tmm/courses/cheat.html".

/*
 File:              mazesolver.c
 Purpose:           displays the shortest path, cheapest path, and cheapest path cost of a maze. 
					with the exit of the maze being the right hand side.
 Author:			Karmen Wang, Matthew Lee
 Student #s:	 	54144183 and 78927936
CS Accounts:	    t6k1b and z9u1b
 Date:				Nov 5 2018
 */


/*
 File:              mazesolver.h
 Purpose:           Contains constants, prototypes, globals
 Author:			Karmen Wang, Matthew Lee
 Student #s:	 	54144183 and 78927936
 CS Accounts:	    t6k1b and z9u1b
 Date:				Nov 5 2018
 */

checking for correctness: used debugger and to-do #9 to check our outputs with respective maze files. 

challenges: remembering restraints and small bugs in each function

Hours spent: 1-2 hour in total (mostly debugging)

How the assignment was split: 50% for matthew  and 50% for karmen. Programming was split evenly between the two partners.
