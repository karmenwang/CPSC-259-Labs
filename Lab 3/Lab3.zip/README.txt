 "We have read and understood the plagiarism policies at 
https://www.cs.ubc.ca/our-department/administration/policies/collaboration 
and we understand that no excuse for plagiarism will be accepted, including 
any listed in http://www.cs.ubc.ca/~tmm/courses/cheat.html".

/*
 File:        linkedlist.c
 Purpose:           Implements the linked list functions whose prototypes
                    are declared in the linked_list.h header file
 Author:	Karmen Wang and Matthew Lee
 Student #s:	54144183 and 78927936
 CS Accounts:	t6k1b and z9u1b
 Date:			oct 22 2018
 */

/*
 File:              linkedlist.c
 Purpose:           Prototypes for a linked list implementation
Author:	 Karmen Wang and Matthew Lee
 Student #s:	54144183 and 78927936
 CS Accounts:	t6k1b and z9u1b
 Date:			oct 22 2018
 */

checking for correctness: used debugger and unit tests to see which cases were not met. 

challenges: keeping track of linked list abstract diagram and what to do with each node

Hours spent: 2-3 hours in total (mostly debugging)

How the assignment was split: 50% for matthew  and 50% for karmen. Programming was split evenly between the two partners.
